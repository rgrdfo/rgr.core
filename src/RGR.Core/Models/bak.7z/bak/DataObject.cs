﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RGR.Core.Models
{
    //Объекты данных. Класс инкапсулирует описание всех ДО а так же методы преобразования в БО и обратно
    public partial class DataObject
    {
        public interface IdbObject
        {
            long Id { get; set; }
        }

        public class Achievment : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public DateTime ReachDate { get; set; }
            public string Title { get; set; }
            public string Organizer { get; set; }
            public string ScanUrl { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class Address : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public long CountryId { get; set; }
            public long RegionId { get; set; }
            public long CityId { get; set; }
            public long RegionDistrictId { get; set; }
            public long CityDistrictId { get; set; }
            public long DistrictResidentialAreaId { get; set; }
            public long StreetId { get; set; }
            public string House { get; set; }
            public string Block { get; set; }
            public string Flat { get; set; }
            public string Land { get; set; }
            public float Latitude { get; set; }
            public float Logitude { get; set; }
        }


        public class Article : IdbObject
        {
            public long Id { get; set; }
            public long Title { get; set; }
            public short ArticleType { get; set; }
            public DateTime PublicationDate { get; set; }
            public string ShortContent { get; set; }
            public string FullContent { get; set; }
            public string PreviewImage { get; set; }
            public string VideoLink { get; set; }
            public int Views { get; set; }
            public DateTime DateCreated{ get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
         }

        public class AuditEvent : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public DateTime EventDate { get; set; }
            public short EventType { get; set; }
            public string Message { get; set; }
            public string IP { get; set; }
            public string BrowserInfo { get; set; }
            public string AdditionalInformation { get; set; }
        }

        public class Banner : IdbObject
        { 
            public long Id { get; set; }
            public string Title { get; set; }
            public short Location { get; set; }
            public short Type { get; set; }
            public string ObjectUrl { get; set; }
            public string LinkUrl { get; set; }
            public int Views { get; set; }
            public int Clicks { get; set; }
            public int ShowProbability { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class Book : IdbObject
        {
            public long Id { get; set; }
            public string Title { get; set; }
            public string Publisher { get; set; }
            public decimal Price { get; set; }
            public string Description { get; set; }
            public string Picture { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public string Authorusing { get; set; }
        }

        public class ClientReview : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public long ObjectId { get; set; }
            public DateTime ReviewDate { get; set; }
            public string Description { get; set; }
            public string ScanUrl { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public short Operation { get; set; }
        }

        public class Client : IdbObject
        {
            public long Id { get; set; }
            public long CompanyId { get; set; }
            public string Email { get; set; }
            public string Address { get; set; }
            public DateTime AgreementDate { get; set; }
            public DateTime AgreementEndDate { get; set; }
            public DateTime Birthday { get; set; }
            public bool Blacklisted { get; set; }
            public string Commision { get; set; }
            public string ICQ { get; set; }
            public string AgreementNumber { get; set; }
            public bool AgencyPayment { get; set; }
            public string Notes { get; set; }
            public string Phone { get; set; }
            public short AgreementType { get; set; }
            public short ClientType { get; set; }
            public string PaymentConditions { get; set; }
            public string LastName { get; set; }
            public string FirstName { get; set; }
            public string SurName { get; set; }
            public long PassportId { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class Comment : IdbObject
        {
            public long Id { get; set; }
            public long EntityId { get; set; }
            public short EntityType { get; set; }
            public long UserId { get; set; }
            public string AuthorName { get; set; }
            public string AuthiorEmail { get; set; }
            public string Content { get; set; }
            public string RequestData { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class Company : IdbObject
        {
            public long Id { get; set; }
            public string Name { get; set; }
            public long CityId { get; set; }
            public string Address { get; set; }
            public string Phone1 { get; set; }
            public string Phone2 { get; set; }
            public string Phone3 { get; set; }
            public string Email { get; set; }
            public string LogoImageUrl { get; set; }
            public string LocationSchemeUrl { get; set; }
            public string Description { get; set; }
            public long CompanyType { get; set; }
            public long DirectorId { get; set; }
            public string Branch { get; set; }
            public string ContactPerson { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
            public bool Inactive { get; set; }
            public bool IsServiceProvider { get; set; }
            public bool NDSPayer { get; set; }
            public string ShortName { get; set; }
        }

        public class Dictionary : IdbObject
        {
            public long Id { get; set; }
            public string SystemName { get; set; }
            public string DisplayName { get; set; }
            public string Description { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class DictionaryValue : IdbObject
        {
            public long Id { get; set; }
            public long DictionaryId { get; set; }
            public string Value { get; set; }
            public string ShortValue { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class EstateObjectMatchedSearchRequestComment : IdbObject
        {
            public long Id { get; set; }
            public long MatchedRequestId { get; set; }
            public long UserId { get; set; }
            public string Text { get; set; }
            public DateTime DateCreated { get; set; }
        }

        public class EstateObjectMatchedSearchRequest : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public long RequestId { get; set; }
            public long RequestUserId { get; set; }
            public short Status { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateMoved { get; set; }
            public string RequestTitle { get; set; }
            public DateTime RequestDateCreated { get; set; }
            public DateTime RequestDateDeleted { get; set; }
        }

        public class EstateObject : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public long ClientId { get; set; }
            public short ObjectType { get; set; }
            public short Operation { get; set; }
            public short Status { get; set; }
            public bool Filled { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class GeoCity : IdbObject
        {
            public long Id { get; set; }
            public long RegionDistrictId { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoCountry : IdbObject
        {
            public long Id { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoDistrict : IdbObject
        {
            public long Id { get; set; }
            public long CityId { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public string Bounds { get; set; }
            public string Description { get; set; }
            public int Population { get; set; }
        }

        public class GeoLandmark : IdbObject
        {
            public long Id { get; set; }
            public string Name { get; set; }
            public long CityId { get; set; }
            public long DistrictId { get; set; }
            public long AreaId { get; set; }
            public long StreetId { get; set; }
            public double Latitude { get; set; }
            public double Longitude { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoObjectInfo : IdbObject
        {
            public long Id { get; set; }
            public long GeoObjectId { get; set; }
            public string Number { get; set; }
            public string Liter { get; set; }
            public int EntranceCount { get; set; }
            public bool Community { get; set; }
            public string CommunityName { get; set; }
            public string BuildingMaterial { get; set; }
            public int FloorsCount { get; set; }
            public string Planning { get; set; }
            public int BuildYear { get; set; }
            public string Description { get; set; }
            public double Latitude { get; set; }
            public double Longitude { get; set; }
            public string Photo { get; set; }
            public string Builder { get; set; }
            public string CelingMaterial { get; set; }
            public bool Gas { get; set; }
            public bool Locked { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoObject : IdbObject
        {
            public long Id { get; set; }
            public long StreetId { get; set; }
            public string Name { get; set; }
            public double Latitude { get; set; }
            public double Longitude { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoRegionDistrict : IdbObject
        {
            public long Id { get; set; }
            public long RegionId { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoRegion : IdbObject
        {
            public long Id { get; set; }
            public long CountryId { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class GeoResidentialArea : IdbObject
        {
            public long Id { get; set; }
            public long DistrictId { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public string Bounds { get; set; }
            public string Description { get; set; }
        }

        public class GeoStreet : IdbObject
        {
            public long Id { get; set; }
            public long AreaId { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class MailNotificationMessage : IdbObject
        {
            public long Id { get; set; }
            public string Recipient { get; set; }
            public string Subject { get; set; }
            public string Content { get; set; }
            public bool Sended { get; set; }
            public DateTime DateEnqued { get; set; }
            public DateTime DateSended { get; set; }
        }

        public class MenuItem : IdbObject
        {
            public long Id { get; set; }
            public string Title { get; set; }
            public string Href { get; set; }
            public int Position { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class NonRdvAgent : IdbObject
        {
            public long Id { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string SurName { get; set; }
            public string Phone { get; set; }
            public DateTime DateCreated { get; set; }
        }


        public class ObjectAdditionalProperty : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public string ViewFromWindows { get; set; }
            public int BuildingYear { get; set; }
            public string AdditionalBuildings { get; set; }
            public bool ExtensionsLegality { get; set; }
            public long Builder { get; set; }
            public int BalconiesCount { get; set; }
            public int RoomsCount { get; set; }
            public int LoggiasCount { get; set; }
            public int BedroomsCount { get; set; }
            public int BaywindowsCount { get; set; }
            public long Roof { get; set; }
            public string ObjectName { get; set; }
            public long Fencing { get; set; }
            public long RoomPlanning { get; set; }
            public string Basement { get; set; }
            public bool CorrectPlanning { get; set; }
            public long FlatLocation { get; set; }
            public string WindowsLocation { get; set; }
            public string WindowsMaterial { get; set; }
            public bool Redesign { get; set; }
            public bool RedesignLegality { get; set; }
            public long PlotForm { get; set; }
            public int FlatRoomsCount { get; set; }
            public int ErkersCount { get; set; }
            public bool RegistrationPosibility { get; set; }
            public long OwnerPart { get; set; }
            public long Burdens { get; set; }
            public DateTime RentDate { get; set; }
            public long Court { get; set; }
            public long Fence { get; set; }
            public string Loading { get; set; }
            public long Environment { get; set; }
            public bool RentWithServices { get; set; }
            public bool Auction { get; set; }
            public long Placement { get; set; }
            public long AgreementType { get; set; }
            public string AgreementNumber { get; set; }
            public DateTime AgreementStartDate { get; set; }
            public DateTime AgreementEndDate { get; set; }
            public string Comission { get; set; }
            public bool AgencyPayment { get; set; }
            public string PaymentCondition { get; set; }
        }

        public class ObjectChangementProperty : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public double PriceChanging { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public DateTime ViewDate { get; set; }
            public DateTime DateMoved { get; set; }
            public DateTime DateRegisted { get; set; }
            public DateTime DealDate { get; set; }
            public DateTime DelayToDate { get; set; }
            public DateTime PriceChanged { get; set; }
            public DateTime AdvanceDate { get; set; }
            public long CreatedBy { get; set; }
            public long ChangedBy { get; set; }
            public long StatusChangedBy { get; set; }
        }

        public class ObjectClient : IdbObject
        {
            public long Id { get; set; }
            public long ClientId { get; set; }
            public long ObjectId { get; set; }
            public DateTime DateCreated { get; set; }
        }

        public class ObjectCommunication : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public string Water { get; set; }
            public string Gas { get; set; }
            public long Sewer { get; set; }
            public string Heating { get; set; }
            public string Phone { get; set; }
            public string Tubes { get; set; }
            public string Electricy { get; set; }
            public string SanFurniture { get; set; }
            public bool HasGasMeter { get; set; }
            public bool HasColdWaterMeter { get; set; }
            public bool HasHotWaterMeter { get; set; }
            public bool HasElectricyMeter { get; set; }
            public bool HasInternet { get; set; }
        }

        public class ObjectHistoryEntry : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public short HistoryStatus { get; set; }
            public long ClientId { get; set; }
            public long CompanyId { get; set; }
            public string CustomerName { get; set; }
            public DateTime DelayDate { get; set; }
            public long DelayReason { get; set; }
            public DateTime DateCreated { get; set; }
            public long CreatedBy { get; set; }
            public DateTime AdvanceEndDate { get; set; }
            public long RDVAgentId { get; set; }
            public long NonRDVAgentId { get; set; }
        }

        public class ObjectMainProperty : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public double RentPerDay { get; set; }
            public double RentPerMonth { get; set; }
            public string Security { get; set; }
            public long Currency { get; set; }
            public long PropertyType { get; set; }
            public bool Negotiable { get; set; }
            public bool ResidencePermit { get; set; }
            public double CelingHeight { get; set; }
            public double AtticHeight { get; set; }
            public long Yard { get; set; }
            public long OwnerShare { get; set; }
            public string AddCommercialBuildings { get; set; }
            public double ActualUsableFloorArea { get; set; }
            public double FirstFloorDownSet { get; set; }
            public string Title { get; set; }
            public bool MortgagePossibility { get; set; }
            public long MortgageBank { get; set; }
            public string ObjectUsage { get; set; }
            public bool NonResidenceUsage { get; set; }
            public long BuildingClass { get; set; }
            public int WindowsCount { get; set; }
            public int PrescriptionsCount { get; set; }
            public int FamiliesCount { get; set; }
            public int OwnersCount { get; set; }
            public int PhoneLinesCount { get; set; }
            public int LevelsCount { get; set; }
            public int FacadeWindowsCount { get; set; }
            public bool UtilitiesRentExspensive { get; set; }
            public string ShortDescription { get; set; }
            public string FloorMaterial { get; set; }
            public string BuildingMaterial { get; set; }
            public string LandAssignment { get; set; }
            public string ObjectAssignment { get; set; }
            public bool HasWeights { get; set; }
            public bool HasPhotos { get; set; }
            public bool NewBuilding { get; set; }
            public double TotalArea { get; set; }
            public long Landmark { get; set; }
            public string ReleaseInfo { get; set; }
            public bool HasParking { get; set; }
            public long BuildingPeriod { get; set; }
            public double BigRoomFloorArea { get; set; }
            public double BuildingFloor { get; set; }
            public double KitchenFloorArea { get; set; }
            public double LandArea { get; set; }
            public double LandFloorFactical { get; set; }
            public long Loading { get; set; }
            public string FullDescription { get; set; }
            public long EntranceToObject { get; set; }
            public bool AbilityForMachineryEntrance { get; set; }
            public string Documents { get; set; }
            public bool Prepayment { get; set; }
            public string Notes { get; set; }
            public long RemovalReason { get; set; }
            public string LivingPeoples { get; set; }
            public string LivingPeolplesDescription { get; set; }
            public long EntryLocation { get; set; }
            public double DistanceToCity { get; set; }
            public double DistanceToSea { get; set; }
            public string FootageExplanation { get; set; }
            public string Advertising1 { get; set; }
            public string Advertising2 { get; set; }
            public string Advertising3 { get; set; }
            public string Advertising4 { get; set; }
            public string Advertising5 { get; set; }
            public long Relief { get; set; }
            public bool SpecialOffer { get; set; }
            public string SpecialOfferDescription { get; set; }
            public DateTime LeaseTime { get; set; }
            public bool Urgently { get; set; }
            public double BuildingReadyPercent { get; set; }
            public long HouseType { get; set; }
            public long FlatType { get; set; }
            public long BuildingType { get; set; }
            public bool Exchange { get; set; }
            public string ExchangeConditions { get; set; }
            public bool HousingStock { get; set; }
            public long Foundation { get; set; }
            public double Price { get; set; }
            public double PricePerUnit { get; set; }
            public double PricePerHundred { get; set; }
            public double OwnerPrice { get; set; }
            public int PricingZone { get; set; }
            public long HowToReach { get; set; }
            public double ElectricPower { get; set; }
            public int FloorNumber { get; set; }
            public int TotalFloors { get; set; }
            public long ContractorCompany { get; set; }
            public string RentOverpayment { get; set; }
            public double RealPrice { get; set; }
            public string MetricDescription { get; set; }
            public string SellConditions { get; set; }
            public bool Exclusive { get; set; }
            public double MultilistingBonus { get; set; }
            public long MultilistingBonusType { get; set; }
            public long ContactPersonId { get; set; }
            public bool IsSetNumberAgency { get; set; }
            public short ContactPhone { get; set; }
            public long ContactCompanyId { get; set; }
        }

        public class ObjectManagerNotification : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public short NotificationType { get; set; }
            public DateTime DateCreated { get; set; }
        }

        public class ObjectMedia : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public short MediaType { get; set; }
            public string Title { get; set; }
            public string PreviewUrl { get; set; }
            public string MediaUrl { get; set; }
            public int Views { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
            public int Position { get; set; }
            public bool IsMain { get; set; }
        }

        public class ObjectPriceChangement : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public long Currency { get; set; }
            public double Value { get; set; }
            public DateTime DateChanged { get; set; }
            public long ChangedBy { get; set; }
        }

        public class ObjectRatingProperty : IdbObject
        {
            public long Id { get; set; }
            public long ObjectId { get; set; }
            public string Balcony { get; set; }
            public string EntranceDoor { get; set; }
            public string Kitchen { get; set; }
            public string KitchenDescription { get; set; }
            public string Ladder { get; set; }
            public string Loggia { get; set; }
            public long CommonState { get; set; }
            public string WindowsDescription { get; set; }
            public string UtilityRooms { get; set; }
            public string Floor { get; set; }
            public string Ceiling { get; set; }
            public string Furniture { get; set; }
            public string WC { get; set; }
            public string WCDescription { get; set; }
            public int Rating { get; set; }
            public string Walls { get; set; }
            public string Carpentry { get; set; }
            public string Vestibule { get; set; }
            public bool Multilisting { get; set; }
            public long BuildingClass { get; set; }
        }

        public class Partner : IdbObject
        {
            public long Id { get; set; }
            public string Name { get; set; }
            public string Url { get; set; }
            public string InactiveImageUrl { get; set; }
            public string ActiveImageUrl { get; set; }
            public int Position { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class Passport : IdbObject
        {
            public long Id { get; set; }
            public string Series { get; set; }
            public string Number { get; set; }
            public string IssuesBy { get; set; }
            public DateTime IssueDate { get; set; }
            public string RegistrationPlace { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class Payment : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public long CompanyId { get; set; }
            public short Direction { get; set; }
            public decimal Amount { get; set; }
            public string Description { get; set; }
            public bool Payed { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DatePayed { get; set; }
        }

        public class Permission : IdbObject
        {
            public long Id { get; set; }
            public string SystemName { get; set; }
            public string DisplayName { get; set; }
            public string PermissionGroup { get; set; }
            public bool OperationContext { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }


        public class RolePermissionOption : IdbObject
        {
            public long Id { get; set; }
            public long RolePermissionId { get; set; }
            public short ObjectOperation { get; set; }
            public short ObjectType { get; set; }
            public DateTime DateCreated { get; set; }
        }

        public class RolePermission : IdbObject
        {
            public long Id { get; set; }
            public long RoleId { get; set; }
            public long PermissionId { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class Role : IdbObject
        {
            public long Id { get; set; }
            public string Name { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class SearchRequestObjectComment : IdbObject
        {
            public long Id { get; set; }
            public long RequestObjectId { get; set; }
            public long UserId { get; set; }
            public string Text { get; set; }
            public DateTime DateCreated { get; set; }
        }

        public class SearchRequestObject : IdbObject
        {
            public long Id { get; set; }
            public long SearchRequestId { get; set; }
            public long EstateObjectId { get; set; }
            public short Status { get; set; }
            public bool New { get; set; }
            public string DeclineReason { get; set; }
            public bool DeclineReasonPrice { get; set; }
            public double OldPrice { get; set; }
            public short TriggerEvent { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateMoved { get; set; }
        }

        public class SearchRequest : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public string Title { get; set; }
            public string SearchUrl { get; set; }
            public int TimesUsed { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class ServiceLogItem : IdbObject
        {
            public long Id { get; set; }
            public long ServiceId { get; set; }
            public decimal Volume { get; set; }
            public decimal Summary { get; set; }
            public decimal RDVSummary { get; set; }
            public long UserId { get; set; }
            public long CompanyId { get; set; }
            public DateTime OrderDate { get; set; }
            public DateTime PaymentDate { get; set; }
        }

        public class ServiceType : IdbObject
        {
            public long Id { get; set; }
            public string ServiceName { get; set; }
            public long ProvidedId { get; set; }
            public decimal Tax { get; set; }
            public long Measure { get; set; }
            public string Description { get; set; }
            public long Subject { get; set; }
            public string Geo { get; set; }
            public short ServiceStatus { get; set; }
            public decimal RDVShare { get; set; }
            public string Rules { get; set; }
            public string Examples { get; set; }
            public string ContractNumber { get; set; }
            public DateTime ContractDate { get; set; }
            public string ContractScan { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class Setting : IdbObject
        {
            public long Id { get; set; }
            public string Name { get; set; }
            public string Title { get; set; }
            public string Description { get; set; }
            public string Value { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
        }

        public class SMSNotificationMessage : IdbObject
        {
            public long Id { get; set; }
            public string Recipient { get; set; }
            public string Message { get; set; }
            public bool Sended { get; set; }
            public DateTime DateEnqueued { get; set; }
            public DateTime DateSended { get; set; }
        }

        public class StaticPage : IdbObject //Шоэта?!
        {
            public long Id { get; set; }
            public string Title { get; set; }
            public string Content { get; set; }
            public string Route { get; set; }
            public int Views { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class StoredFile : IdbObject
        {
            public long Id { get; set; }
            public string MimeType { get; set; }
            public long ContentSize { get; set; }
            public string OriginalFilename { get; set; }
            public string ServerFilename { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
        }

        public class SystemStatsEntry : IdbObject
        {
            public long Id { get; set; }
            public short StatType { get; set; }
            public DateTime StatDateTime { get; set; }
            public decimal Value { get; set; }
        }

        public class TrainingProgram : IdbObject
        {
            public long Id { get; set; }
            public long UserId { get; set; }
            public DateTime TrainingDate { get; set; }
            public string ProgramName { get; set; }
            public string Organizer { get; set; }
            public string TrainingPlace { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
            public string CertificateFile { get; set; }
        }

        public class User : IdbObject
        {
            public long Id { get; set; }
            public long CompanyId { get; set; }
            public long RoleId { get; set; }
            public string Login { get; set; }
            public string PasswordHash { get; set; }
            public string FirstName { get; set; }
            public string SurName { get; set; }
            public string LastName { get; set; }
            public string Phone { get; set; }
            public string Phone2 { get; set; }
            public string Email { get; set; }
            public string ICQ { get; set; }
            public string Appointment { get; set; }
            public string PhotoUrl { get; set; }
            public bool Blocked { get; set; }
            public bool Activated { get; set; }
            public string CertificateNumber { get; set; }
            public DateTime CertificationDate { get; set; }
            public DateTime SeniorityStartDate { get; set; }
            public DateTime Birthdate { get; set; }
            public long PassportId { get; set; }
            public DateTime LastLogin { get; set; }
            public DateTime DateCreated { get; set; }
            public DateTime DateModified { get; set; }
            public long CreatedBy { get; set; }
            public long ModifiedBy { get; set; }
            public int Status { get; set; }
            public string AdditionalInformation { get; set; }
            public string PublicLoading { get; set; }
            public DateTime CertificateEndDate { get; set; }
            public short Notifications { get; set; }
        }
    }
}
