﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace RGR.Core.Models
{
    public class Context : DbContext
    {
        public DbSet<DataObject.Achievment> Achievments { get; set; }
        public DbSet<DataObject.Address> Addresses { get; set; }
        public DbSet<DataObject.Article> Articles { get; set; }
        public DbSet<DataObject.AuditEvent> AuditEvents { get; set; }
        public DbSet<DataObject.Banner> Banners { get; set; }
        public DbSet<DataObject.Book> Books { get; set; }
        public DbSet<DataObject.ClientReview> ClientReviews { get; set; }
        public DbSet<DataObject.Client> Clients { get; set; }
        public DbSet<DataObject.Comment> Comments { get; set; }
        public DbSet<DataObject.Company> Companies { get; set; }
        public DbSet<DataObject.Dictionary> Dictionaries { get; set; }
        public DbSet<DataObject.DictionaryValue> DictionaryValues { get; set; }
        public DbSet<DataObject.EstateObjectMatchedSearchRequestComment> EstateObjectMatchedSearchRequestComments { get; set; }
        public DbSet<DataObject.EstateObjectMatchedSearchRequest> EstateObjectMatchedSearchRequests { get; set; }
        public DbSet<DataObject.EstateObject> EstateObjects { get; set; }
        public DbSet<DataObject.GeoCity> GeoCities { get; set; }
        public DbSet<DataObject.GeoCountry> GeoCountries { get; set; }
        public DbSet<DataObject.GeoDistrict> GeoDistricts { get; set; }
        public DbSet<DataObject.GeoLandmark> GeoLandmarks { get; set; }
        public DbSet<DataObject.GeoObjectInfo> GeoObjectInfos { get; set; }
        public DbSet<DataObject.GeoObject> GeoObjects { get; set; }
        public DbSet<DataObject.GeoRegionDistrict> GeoRegionDistricts { get; set; }
        public DbSet<DataObject.GeoRegion> GeoRegions { get; set; }
        public DbSet<DataObject.GeoResidentialArea> GeoResidentialAreas { get; set; }
        public DbSet<DataObject.GeoStreet> GeoStreets { get; set; }
        public DbSet<DataObject.MailNotificationMessage> MailNotificationMessages { get; set; }
        public DbSet<DataObject.MenuItem> MenuItems { get; set; }
        public DbSet<DataObject.NonRdvAgent> NonRdvAgents { get; set; }
        public DbSet<DataObject.ObjectAdditionalProperty> ObjectAdditionalProperties { get; set; }
        public DbSet<DataObject.ObjectChangementProperty> ObjectChangementProperties { get; set; }
        public DbSet<DataObject.ObjectClient> ObjectClients { get; set; }
        public DbSet<DataObject.ObjectCommunication> ObjectCommunications { get; set; }
        public DbSet<DataObject.ObjectHistoryEntry> ObjectHistory { get; set; }
        public DbSet<DataObject.ObjectMainProperty> ObjectMainProperties { get; set; }
        public DbSet<DataObject.ObjectManagerNotification> ObjectManagerNotifications { get; set; }
        public DbSet<DataObject.ObjectMedia> ObjectMedias { get; set; }
        public DbSet<DataObject.ObjectPriceChangement> ObjectPriceChangements { get; set; }
        public DbSet<DataObject.ObjectRatingProperty> ObjectRatingProperties { get; set; }
        public DbSet<DataObject.Partner> Partners { get; set; }
        public DbSet<DataObject.Passport> Passports { get; set; }
        public DbSet<DataObject.Payment> Paymenst { get; set; }
        public DbSet<DataObject.Permission> Permissions { get; set; }
        public DbSet<DataObject.RolePermissionOption> RolePermissionOptions { get; set; }
        public DbSet<DataObject.RolePermission> RolePermissions { get; set; }
        public DbSet<DataObject.Role> Roles { get; set; }
        public DbSet<DataObject.SearchRequestObjectComment> SearchRequestObjectComments { get; set; }
        public DbSet<DataObject.SearchRequestObject> SearchRequestObjects { get; set; }
        public DbSet<DataObject.SearchRequest> SearchRequests { get; set; }
        public DbSet<DataObject.ServiceLogItem> ServiceLogItems { get; set; }
        public DbSet<DataObject.ServiceType> ServiceTypes { get; set; }
        public DbSet<DataObject.Setting> Settings { get; set; }
        public DbSet<DataObject.SMSNotificationMessage> SMSNotificationMessages { get; set; }
        public DbSet<DataObject.StaticPage> StaticPages { get; set; }
        public DbSet<DataObject.StoredFile> StoredFiles { get; set; }
        public DbSet<DataObject.SystemStatsEntry> SystemStats { get; set; }
        public DbSet<DataObject.TrainingProgram> TrainingPrograms { get; set; }
        public DbSet<DataObject.User> Users { get; set; }

        public Context(DbContextOptions<Context> options) : base(options) { }
    }
}
