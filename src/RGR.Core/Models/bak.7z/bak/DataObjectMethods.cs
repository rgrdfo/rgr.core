﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RGR.Core.Models
{/*
    public partial class DataObject
    {
        //Получение объекта данных из бизнес-объекта
        public static dynamic Set(BuisnessObject bObject)
        {
            //object output;
            if (bObject is Person)
            {
                var output = new doPerson();

                output.ID = bObject.ID;
                output.CreationTime = bObject.CreationTime;
                output.FirstName = ((Person)bObject).FirstName;
                output.SecondName = ((Person)bObject).SecondName;
                output.LastName = ((Person)bObject).LastName;
                output.Birthday = ((Person)bObject).Birthday;

                return output;
            }

            else if (bObject is Organization)
            {
                var output = new doOrganization();

                output.ID = bObject.ID;
                output.CreationTime = bObject.CreationTime;
                output.Name = ((Organization)bObject).Name;
                output.Members = ((Organization)bObject).Members.ToArray();

                return output;
            }

            //Некорректный тип данныъ
            throw new ArgumentException("Ты мне впариваешь какую-то дичь", "bObject");
        }


        //Получение бизнес-объекта из объекта данных
        public static BuisnessObject Get(dynamic dObject)
        {
            if (dObject is doPerson)
                return new Person
                    (
                        ((doPerson)dObject).ID,
                        ((doPerson)dObject).CreationTime,
                        ((doPerson)dObject).FirstName,
                        ((doPerson)dObject).SecondName,
                        ((doPerson)dObject).LastName,
                        ((doPerson)dObject).Birthday
                    );

            else if (dObject is doOrganization)
                return new Organization
                    (
                        ((doOrganization)dObject).ID,
                        ((doOrganization)dObject).CreationTime,
                        ((doOrganization)dObject).Members
                    );

            //Некорректный тип данныъ
            throw new ArgumentException("Ты мне впариваешь какую-то дичь", "dObject");
        }
    }
*/}
